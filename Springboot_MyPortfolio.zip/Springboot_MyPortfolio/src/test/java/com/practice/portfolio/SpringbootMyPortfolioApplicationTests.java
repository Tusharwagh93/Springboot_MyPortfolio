package com.practice.portfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMyPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
