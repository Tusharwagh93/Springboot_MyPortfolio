package com.practice.portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMyPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMyPortfolioApplication.class, args);
	}

}
